# AccessManager Design — Mermaid Diagrams

These are alternate Mermaid versions of both diagrams. To import into draw.io:
1. Open draw.io
2. Arrange menu → Insert → Advanced → Mermaid
3. Paste the Mermaid block (without the ```mermaid fences)
4. Click Insert

---

## Diagram 1: Daily AccessManager Assignment Task

```mermaid
flowchart TD
    Start([Scheduled Task Fires<br/>Daily, off-hours])
    Iterate[Iterate Active Identities]
    Read[Read Identity Attributes<br/>CC, BU, BG, Dept]
    Validate{Key Attributes<br/>Present?}
    Skip[Skip Identity<br/>Log to exception report]
    Lookup[Lookup Mapping Table<br/>Custom:AccessManagerMapping]
    Match{Mapping Match<br/>Found?}
    SetWG[Set Workgroup<br/>accessManager = mapped wg]
    Default[Set Default Workgroup<br/>Unmapped Access queue]
    Next([Next Identity or Finish])

    Start --> Iterate
    Iterate --> Read
    Read --> Validate
    Validate -- No --> Skip
    Validate -- Yes --> Lookup
    Lookup --> Match
    Match -- Yes --> SetWG
    Match -- No --> Default
    SetWG --> Next
    Default --> Next
    Skip --> Next

    style Start fill:#dae8fc,stroke:#6c8ebf
    style Iterate fill:#dae8fc,stroke:#6c8ebf
    style Read fill:#dae8fc,stroke:#6c8ebf
    style Lookup fill:#dae8fc,stroke:#6c8ebf
    style Validate fill:#fff2cc,stroke:#d6b656
    style Match fill:#fff2cc,stroke:#d6b656
    style Skip fill:#f8cecc,stroke:#b85450
    style SetWG fill:#d5e8d4,stroke:#82b366
    style Default fill:#e1d5e7,stroke:#9673a6
    style Next fill:#f5f5f5,stroke:#666666
```

---

## Diagram 2: Access Request Approval Workflow

```mermaid
flowchart TD
    Requester([Requester Submits<br/>LCM Access Request])
    Capture[Workflow Captures Vars<br/>launcher, identityName]
    MgrStep[Manager Approval Step<br/>Owner rule evaluates]
    AMSet{accessManager Set<br/>on Target?}
    SelfReq{launcher == target?<br/>Self-request guard}
    IsAM{launcher is<br/>AccessManager?<br/>Workgroup membership}
    Fallback[Fallback Path<br/>Route to identity.manager<br/>source: FALLBACK_MGR]
    Self[Self-request Variant<br/>Route to AccessMgr wg<br/>Exclude launcher<br/>source: SELF_REQUEST]
    Rule2[Rule 2: Route to Assigned AccessMgr<br/>Workgroup any member<br/>source: ACCESSMGR_APPROVAL]
    Rule1[Rule 1: Auto Approve<br/>Launcher is AccessManager<br/>source: AUTO_ACCESSMGR]
    Decision[Approver Decision<br/>approve, reject, or auto]
    Audit[Audit Log Written<br/>approvalSource recorded]
    Approved{Approved?}
    Denied[Request Denied<br/>Notify requester]
    Provision[Provisioning Executes<br/>Entitlements assigned]
    End([Workflow Ends])

    Requester --> Capture
    Capture --> MgrStep
    MgrStep --> AMSet
    AMSet -- No --> Fallback
    AMSet -- Yes --> SelfReq
    SelfReq -- Yes --> Self
    SelfReq -- No --> IsAM
    IsAM -- No --> Rule2
    IsAM -- Yes --> Rule1
    Self --> Rule2
    Rule2 --> Decision
    Rule1 --> Decision
    Fallback --> Decision
    Decision --> Audit
    Audit --> Approved
    Approved -- No --> Denied
    Approved -- Yes --> Provision
    Denied --> End
    Provision --> End

    style Requester fill:#f5f5f5,stroke:#666666
    style Capture fill:#dae8fc,stroke:#6c8ebf
    style MgrStep fill:#dae8fc,stroke:#6c8ebf
    style Audit fill:#dae8fc,stroke:#6c8ebf
    style AMSet fill:#fff2cc,stroke:#d6b656
    style SelfReq fill:#fff2cc,stroke:#d6b656
    style IsAM fill:#fff2cc,stroke:#d6b656
    style Approved fill:#fff2cc,stroke:#d6b656
    style Fallback fill:#e1d5e7,stroke:#9673a6
    style Self fill:#ffe6cc,stroke:#d79b00
    style Rule1 fill:#d5e8d4,stroke:#82b366
    style Rule2 fill:#d5e8d4,stroke:#82b366
    style Provision fill:#d5e8d4,stroke:#82b366
    style Decision fill:#f5f5f5,stroke:#666666
    style Denied fill:#f8cecc,stroke:#b85450
    style End fill:#f5f5f5,stroke:#666666
```
